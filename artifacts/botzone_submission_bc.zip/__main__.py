from botzone_entry import main
main()
