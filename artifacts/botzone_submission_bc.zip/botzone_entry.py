#!/usr/bin/env python3
"""Botzone JSON-lines entry point.

Loads ``data/model.pt`` when the Botzone runtime provides PyTorch, otherwise
falls back to the dependency-free heuristic policy.
"""
import json
import os
import sys

from mahjong_agent.botzone.protocol import ProtocolState, action_to_text
from mahjong_agent.engine.actions import Action, ActionType
from mahjong_agent.engine.tiles import is_suited
from mahjong_agent.policies import HeuristicPolicy
from mahjong_agent.rules import default_backend


def hu_context(state, self_drawn):
    tile = state.drawn_tile if self_drawn else (state.last_discard[1] if state.last_discard else -1)
    visible = sum(river.count(tile) for river in state.discards) if tile >= 0 else 0
    visible += sum(meld.tiles.count(tile) for melds in state.melds for meld in melds) if tile >= 0 else 0
    return {
        "player_id": state.player_id, "seat_wind": state.player_id,
        "prevalent_wind": state.prevalent_wind, "self_drawn": self_drawn,
        "fourth_tile": tile >= 0 and visible + int(self_drawn) >= 4,
        "about_kong": state.claim_hu_only, "wall_last": False,
        "flower_count": state.flower_counts[state.player_id],
    }


def legal_from_protocol(state):
    observation = state.observation()
    hand = observation["hand"]
    if observation["phase"] == "ack":
        return [Action.pass_()]
    if observation["phase"] == "discard":
        actions = [Action.play(tile) for tile in sorted(set(hand))]
        counts = [hand.count(tile) for tile in range(34)]
        if default_backend.can_hu(
                counts, observation["melds"][observation["player_id"]], state.drawn_tile,
                hu_context(state, True), min_fan=8):
            actions.append(Action.hu())
        for tile, count in enumerate(counts):
            if count == 4:
                actions.append(Action(ActionType.GANG, tile))
        for meld in observation["melds"][observation["player_id"]]:
            if meld.kind == ActionType.PENG and counts[meld.tiles[0]]:
                actions.append(Action(ActionType.BUGANG, meld.tiles[0]))
        return actions
    actions = [Action.pass_()]
    if not observation["last_discard"]:
        return actions
    source, tile = observation["last_discard"]
    counts = [hand.count(item) for item in range(34)]
    counts[tile] += 1
    if default_backend.can_hu(
            counts, observation["melds"][observation["player_id"]], tile,
            hu_context(state, False), min_fan=8):
        actions.append(Action.hu())
    counts[tile] -= 1
    if state.claim_hu_only:
        return actions
    if hand.count(tile) >= 2:
        remaining = list(hand)
        remaining.remove(tile)
        remaining.remove(tile)
        for discard in sorted(set(remaining)):
            actions.append(Action(ActionType.PENG, tile, (), discard))
    if hand.count(tile) >= 3:
        actions.append(Action(ActionType.GANG, tile))
    if state.player_id == (source + 1) % 4 and is_suited(tile):
        base = tile - tile % 9
        offset = tile % 9
        for start in range(max(0, offset - 2), min(6, offset) + 1):
            sequence = (base + start, base + start + 1, base + start + 2)
            needed = list(sequence)
            needed.remove(tile)
            if all(hand.count(item) >= needed.count(item) for item in set(needed)):
                remaining = list(hand)
                for item in needed:
                    remaining.remove(item)
                for discard in sorted(set(remaining)):
                    actions.append(Action(ActionType.CHI, tile, sequence, discard))
    return actions


def load_policy(model_path=None):
    model_path = model_path or os.environ.get("MAHJONG_MODEL", os.path.join("data", "model_sl.pt"))
    try:
        import torch
        from mahjong_agent.models.hybrid_transformer import HybridTransformer
        from mahjong_agent.policies.model import ModelPolicy
        from mahjong_agent.training.checkpoint import load_checkpoint
        model = HybridTransformer()
        load_checkpoint(model_path, model)
        model.to(torch.device("cpu"))
        return ModelPolicy(model)
    except Exception:
        if os.environ.get("MAHJONG_REQUIRE_MODEL") == "1":
            raise
        return HeuristicPolicy()


def main():
    state = ProtocolState()
    payload = json.loads(sys.stdin.readline())
    requests = payload.get("requests", [])
    responses = payload.get("responses", [])
    for index, request in enumerate(requests):
        previous_response = responses[index - 1] if index and index - 1 < len(responses) else None
        state.apply(request, previous_response)
    legal = legal_from_protocol(state)
    action = legal[0] if len(legal) == 1 else load_policy().act(state.observation(), legal)
    print(json.dumps({"response": action_to_text(action)}))


if __name__ == "__main__":
    main()
